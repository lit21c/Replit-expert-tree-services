import { Button } from "@/components/ui/button";
import { Phone, Mail } from "lucide-react";

const CTASection = () => {
  return (
    <section className="relative py-16 md:py-24 bg-primary text-white">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1518761451192-542ccd85d8ae?auto=format&fit=crop&w=1920&h=600&q=80"
          alt="Tree canopy"
          className="object-cover w-full h-full opacity-20"
        />
      </div>
      <div className="container-custom relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-serif font-bold text-3xl md:text-4xl mb-6">
            Ready for Expert Tree Service?
          </h2>
          <p className="text-xl mb-8">
            Contact us today for a free quote on any of our professional tree
            services. Our team is ready to provide the highest quality care for
            your trees.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button
              size="lg"
              variant="outline"
              className="bg-white text-primary hover:bg-gray-100 transition-custom"
              asChild
            >
              <a href="tel:8455551234" className="flex items-center justify-center">
                <Phone className="mr-2 h-4 w-4" /> (845) 555-1234
              </a>
            </Button>
            <Button
              size="lg"
              className="bg-accent hover:bg-secondary transition-custom"
              asChild
            >
              <a href="#contact" className="flex items-center justify-center">
                <Mail className="mr-2 h-4 w-4" /> Contact Us
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
