import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { testimonials } from "@/data/testimonials";

const TestimonialSlider = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slideWidth, setSlideWidth] = useState(100);
  const totalSlides = testimonials.length;

  // Update slide width based on screen size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setSlideWidth(33.33); // 3 slides visible on large screens
      } else if (window.innerWidth >= 768) {
        setSlideWidth(50); // 2 slides visible on medium screens
      } else {
        setSlideWidth(100); // 1 slide visible on small screens
      }
    };

    handleResize(); // Initial call
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prevSlide) => (prevSlide + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentSlide((prevSlide) => (prevSlide - 1 + totalSlides) % totalSlides);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <div className="relative testimonials-slider">
      {/* Testimonial Slides Container */}
      <div className="overflow-hidden">
        <div
          className="flex transition-transform duration-300"
          style={{ transform: `translateX(-${currentSlide * slideWidth}%)` }}
        >
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="w-full md:w-1/2 lg:w-1/3 flex-shrink-0 px-4"
            >
              <Card className="h-full">
                <CardContent className="p-6 h-full flex flex-col">
                  <div className="flex items-center mb-4">
                    <div className="text-accent">
                      {Array(5).fill(0).map((_, i) => (
                        <i 
                          key={i} 
                          className={`fas ${i < testimonial.rating ? 'fa-star' : i + 0.5 === testimonial.rating ? 'fa-star-half-alt' : 'fa-star'}`}
                        ></i>
                      ))}
                    </div>
                  </div>
                  <p className="italic mb-6 flex-grow">{testimonial.text}</p>
                  <div className="flex items-center mt-auto">
                    <div className="mr-4">
                      <div className="w-12 h-12 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                          className={`w-full h-full flex items-center justify-center ${testimonial.bgColor} text-white font-bold text-xl`}
                        >
                          {testimonial.initials}
                        </div>
                      </div>
                    </div>
                    <div>
                      <h4 className="font-bold">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.location}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>

      {/* Slider Controls */}
      <div className="flex justify-center mt-8 space-x-2">
        {Array(totalSlides)
          .fill(0)
          .map((_, index) => (
            <button
              key={index}
              className={`slider-dot w-3 h-3 rounded-full transition-colors ${
                index === currentSlide ? "bg-primary" : "bg-gray-300"
              }`}
              onClick={() => goToSlide(index)}
              aria-label={`Go to slide ${index + 1}`}
            ></button>
          ))}
      </div>

      {/* Navigation Buttons */}
      <Button
        variant="outline"
        size="icon"
        className="absolute top-1/2 -left-4 transform -translate-y-1/2 bg-white rounded-full shadow-md p-3 text-primary hover:text-accent transition-colors hidden md:flex"
        onClick={prevSlide}
        aria-label="Previous testimonial"
      >
        <ChevronLeft className="h-4 w-4" />
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="absolute top-1/2 -right-4 transform -translate-y-1/2 bg-white rounded-full shadow-md p-3 text-primary hover:text-accent transition-colors hidden md:flex"
        onClick={nextSlide}
        aria-label="Next testimonial"
      >
        <ChevronRight className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default TestimonialSlider;
