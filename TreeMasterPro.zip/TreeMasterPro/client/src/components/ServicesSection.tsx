import { Button } from "@/components/ui/button";

interface ServiceCardProps {
  id: string;
  icon: string;
  title: string;
  description: string;
}

const ServiceCard = ({ id, icon, title, description }: ServiceCardProps) => {
  return (
    <div
      id={id}
      className="service-card"
    >
      <div className="bg-primary w-16 h-16 rounded-full flex items-center justify-center mb-6 mx-auto">
        <i className={`fas ${icon} text-white text-2xl`}></i>
      </div>
      <h3 className="font-serif font-bold text-xl text-primary text-center mb-4">
        {title}
      </h3>
      <p className="text-center mb-6">{description}</p>
      <a
        href="#contact"
        className="block text-center text-accent font-semibold hover:text-secondary transition-custom"
      >
        Learn More →
      </a>
    </div>
  );
};

const ServicesSection = () => {
  const services = [
    {
      id: "tree-climbing",
      icon: "fa-climbing",
      title: "Expert Tree Climbing",
      description:
        "Our certified climbers safely access difficult areas to perform precise tree work where equipment can't reach.",
    },
    {
      id: "tree-removal",
      icon: "fa-cut",
      title: "Tree Removal",
      description:
        "Safe and efficient removal of hazardous, dead, or unwanted trees with proper equipment and techniques.",
    },
    {
      id: "pruning",
      icon: "fa-leaf",
      title: "Pruning & Trimming",
      description:
        "Improve tree health, appearance, and safety with professional pruning and crown maintenance.",
    },
    {
      id: "emergency",
      icon: "fa-exclamation-triangle",
      title: "Emergency Services",
      description:
        "24/7 response for storm damage, fallen trees, and other urgent tree-related situations.",
    },
  ];

  return (
    <section id="services" className="py-16 md:py-24">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-4">
            Our Expert Tree Services
          </h2>
          <p className="max-w-3xl mx-auto text-lg">
            We provide comprehensive tree care solutions with a focus on safety,
            expertise, and environmental responsibility.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service) => (
            <ServiceCard
              key={service.id}
              id={service.id}
              icon={service.icon}
              title={service.title}
              description={service.description}
            />
          ))}
        </div>

        <div className="mt-16 text-center">
          <Button
            size="lg"
            className="bg-primary hover:bg-secondary transition-custom"
            asChild
          >
            <a href="#contact">Request a Service Quote</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
