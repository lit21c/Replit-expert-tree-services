import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-primary text-white py-12">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-serif font-bold text-xl mb-4">
              Expert Tree Service
            </h3>
            <p className="mb-4">
              Professional tree care services by certified arborists and expert
              climbers. Fully licensed and insured.
            </p>
            <div className="flex gap-4">
              <a
                href="#"
                className="text-white hover:text-accent transition-custom"
                aria-label="Facebook"
              >
                <i className="fab fa-facebook-f"></i>
              </a>
              <a
                href="#"
                className="text-white hover:text-accent transition-custom"
                aria-label="Instagram"
              >
                <i className="fab fa-instagram"></i>
              </a>
              <a
                href="#"
                className="text-white hover:text-accent transition-custom"
                aria-label="Google"
              >
                <i className="fab fa-google"></i>
              </a>
              <a
                href="#"
                className="text-white hover:text-accent transition-custom"
                aria-label="Yelp"
              >
                <i className="fab fa-yelp"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-serif font-bold text-xl mb-4">Our Services</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="#tree-climbing"
                  className="hover:text-accent transition-custom"
                >
                  Expert Tree Climbing
                </a>
              </li>
              <li>
                <a
                  href="#tree-removal"
                  className="hover:text-accent transition-custom"
                >
                  Tree Removal
                </a>
              </li>
              <li>
                <a
                  href="#pruning"
                  className="hover:text-accent transition-custom"
                >
                  Pruning & Trimming
                </a>
              </li>
              <li>
                <a
                  href="#emergency"
                  className="hover:text-accent transition-custom"
                >
                  Emergency Services
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-custom">
                  Stump Grinding
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-custom">
                  Land Clearing
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-serif font-bold text-xl mb-4">Service Areas</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="hover:text-accent transition-custom">
                  Orange County, NY
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-custom">
                  Sullivan County, NY
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-custom">
                  Ulster County, NY
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-custom">
                  Middletown
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-custom">
                  Kingston
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-accent transition-custom">
                  Monticello
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-serif font-bold text-xl mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <i className="fas fa-map-marker-alt"></i>
                <span>123 Forest Lane, Middletown, NY</span>
              </li>
              <li className="flex items-center gap-2">
                <i className="fas fa-phone-alt"></i>
                <a
                  href="tel:8455551234"
                  className="hover:text-accent transition-custom"
                >
                  (845) 555-1234
                </a>
              </li>
              <li className="flex items-center gap-2">
                <i className="fas fa-envelope"></i>
                <a
                  href="mailto:info@experttreeservice.com"
                  className="hover:text-accent transition-custom"
                >
                  info@experttreeservice.com
                </a>
              </li>
              <li className="flex items-center gap-2">
                <i className="fas fa-clock"></i>
                <span>Mon-Fri: 7AM-6PM, Sat: 8AM-4PM</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white border-opacity-20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p>&copy; {new Date().getFullYear()} Expert Tree Service. All Rights Reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-accent transition-custom">
                Privacy Policy
              </a>
              <a href="#" className="hover:text-accent transition-custom">
                Terms of Service
              </a>
              <a href="#" className="hover:text-accent transition-custom">
                Sitemap
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
