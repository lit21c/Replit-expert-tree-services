import { Button } from "@/components/ui/button";

const AboutSection = () => {
  const images = [
    {
      src: "https://images.unsplash.com/photo-1601587735102-bcea2bfc3f47?auto=format&fit=crop&w=400&h=300&q=80",
      alt: "Tree climbing expert at work",
    },
    {
      src: "https://images.unsplash.com/photo-1523531294919-4bcd7c65e216?auto=format&fit=crop&w=400&h=300&q=80",
      alt: "Professional arborist equipment",
    },
    {
      src: "https://images.unsplash.com/photo-1503066375319-00fef5eed6d4?auto=format&fit=crop&w=400&h=300&q=80",
      alt: "Tree service team",
    },
    {
      src: "https://images.unsplash.com/photo-1541591425126-4e6f741a3ecb?auto=format&fit=crop&w=400&h=300&q=80",
      alt: "Tree service truck and equipment",
    },
  ];

  const credentials = [
    {
      icon: "fas fa-medal",
      title: "Licensed",
    },
    {
      icon: "fas fa-certificate",
      title: "ISA Certified",
    },
    {
      icon: "fas fa-shield-alt",
      title: "Fully Insured",
    },
    {
      icon: "fas fa-thumbs-up",
      title: "5-Star Rated",
    },
  ];

  return (
    <section id="about" className="py-16 md:py-24">
      <div className="container-custom">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="w-full lg:w-1/2 order-2 lg:order-1">
            <div className="grid grid-cols-2 gap-4">
              {images.map((image, index) => (
                <img
                  key={index}
                  src={image.src}
                  alt={image.alt}
                  className="rounded-lg shadow-md w-full h-auto object-cover"
                />
              ))}
            </div>
          </div>

          <div className="w-full lg:w-1/2 order-1 lg:order-2">
            <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-6">
              About Our Company
            </h2>
            <p className="mb-6">
              With over 15 years of experience, Expert Tree Service has been
              providing top-quality tree care to homeowners and businesses
              throughout Orange, Sullivan, and Ulster counties. Our team of ISA
              Certified Arborists and expert climbers is dedicated to the health
              of your trees and the safety of your property.
            </p>

            <p className="mb-8">
              What sets us apart is our specialized climbing techniques that
              allow us to access trees in difficult locations where traditional
              equipment can't reach. This expertise, combined with our
              commitment to safety and environmental responsibility, makes us
              the trusted choice for all tree care needs.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
              {credentials.map((credential, index) => (
                <div
                  key={index}
                  className="bg-gray-50 p-4 rounded-lg text-center"
                >
                  <i className={`${credential.icon} text-accent text-2xl mb-2`}></i>
                  <h4 className="font-semibold">{credential.title}</h4>
                </div>
              ))}
            </div>

            <Button
              className="bg-primary hover:bg-secondary transition-custom"
              asChild
            >
              <a href="#contact">Contact Our Team</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
