import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const contactFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  email: z.string().email("Please enter a valid email address"),
  address: z.string().min(5, "Please enter your property address"),
  service: z.string().min(1, "Please select a service"),
  message: z.string().optional(),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

const ContactSection = () => {
  const { toast } = useToast();
  
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      phone: "",
      email: "",
      address: "",
      service: "",
      message: "",
    },
  });

  const { mutate, isPending } = useMutation({
    mutationFn: (data: ContactFormValues) => {
      return apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Message Sent!",
        description: "We'll get back to you within 24 hours.",
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Something went wrong!",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ContactFormValues) => {
    mutate(data);
  };

  return (
    <section id="contact" className="py-16 md:py-24">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-6">
              Contact Us
            </h2>
            <p className="mb-8">
              Fill out the form below to schedule a consultation or request a
              free quote. Our team will get back to you within 24 hours.
            </p>

            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name *</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number *</FormLabel>
                        <FormControl>
                          <Input type="tel" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address *</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Property Address *</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="service"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service Needed *</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a service..." />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="tree-removal">Tree Removal</SelectItem>
                          <SelectItem value="pruning">Pruning & Trimming</SelectItem>
                          <SelectItem value="emergency">Emergency Service</SelectItem>
                          <SelectItem value="stump-grinding">Stump Grinding</SelectItem>
                          <SelectItem value="land-clearing">Land Clearing</SelectItem>
                          <SelectItem value="consultation">Consultation</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project Details</FormLabel>
                      <FormControl>
                        <Textarea rows={4} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full bg-accent hover:bg-secondary transition-custom"
                  disabled={isPending}
                >
                  {isPending ? "Sending..." : "Send Request"}
                </Button>
              </form>
            </Form>
          </div>

          <div>
            <div className="bg-gray-50 p-8 rounded-lg shadow-md h-full">
              <h3 className="font-serif font-bold text-2xl text-primary mb-6">
                Our Information
              </h3>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="text-accent text-xl mt-1">
                    <i className="fas fa-map-marker-alt"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Office Address</h4>
                    <p>
                      123 Forest Lane
                      <br />
                      Middletown, NY 10940
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="text-accent text-xl mt-1">
                    <i className="fas fa-phone-alt"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Phone</h4>
                    <p>
                      <a
                        href="tel:8455551234"
                        className="hover:text-accent transition-custom"
                      >
                        (845) 555-1234
                      </a>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="text-accent text-xl mt-1">
                    <i className="fas fa-envelope"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Email</h4>
                    <p>
                      <a
                        href="mailto:info@experttreeservice.com"
                        className="hover:text-accent transition-custom"
                      >
                        info@experttreeservice.com
                      </a>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="text-accent text-xl mt-1">
                    <i className="fas fa-clock"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Business Hours</h4>
                    <p>
                      Monday - Friday: 7:00 AM - 6:00 PM
                      <br />
                      Saturday: 8:00 AM - 4:00 PM
                      <br />
                      Sunday: Closed
                      <br />
                      <span className="text-accent font-semibold">
                        24/7 Emergency Service Available
                      </span>
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="text-accent text-xl mt-1">
                    <i className="fas fa-certificate"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1">Credentials</h4>
                    <p>
                      Licensed & Insured
                      <br />
                      ISA Certified Arborists
                      <br />
                      NY State Certified
                      <br />
                      Member of Tree Care Industry Association
                    </p>
                  </div>
                </div>

                <div className="pt-4">
                  <h4 className="font-semibold mb-3">Follow Us</h4>
                  <div className="flex gap-4">
                    <a
                      href="#"
                      className="w-10 h-10 bg-primary text-white flex items-center justify-center rounded-full hover:bg-accent transition-custom"
                      aria-label="Facebook"
                    >
                      <i className="fab fa-facebook-f"></i>
                    </a>
                    <a
                      href="#"
                      className="w-10 h-10 bg-primary text-white flex items-center justify-center rounded-full hover:bg-accent transition-custom"
                      aria-label="Instagram"
                    >
                      <i className="fab fa-instagram"></i>
                    </a>
                    <a
                      href="#"
                      className="w-10 h-10 bg-primary text-white flex items-center justify-center rounded-full hover:bg-accent transition-custom"
                      aria-label="Google"
                    >
                      <i className="fab fa-google"></i>
                    </a>
                    <a
                      href="#"
                      className="w-10 h-10 bg-primary text-white flex items-center justify-center rounded-full hover:bg-accent transition-custom"
                      aria-label="Yelp"
                    >
                      <i className="fab fa-yelp"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
