import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import "leaflet/dist/leaflet.css";
import { MapContainer, TileLayer, Polygon, Tooltip } from "react-leaflet";
import L from 'leaflet';

// Initialize Leaflet icons globally to avoid issues
// This needs to run before any Leaflet components are rendered
import { useIsMobile } from "@/hooks/use-mobile";

const ServiceAreaMap = () => {
  // Set up react-leaflet by fixing icon paths
  useEffect(() => {
    // Fix Leaflet default icon paths
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
      iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
      shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png"
    });
  }, []);

  // Counties boundaries (simplified for demonstration)
  const orangeCounty = [
    [41.45, -74.45],
    [41.45, -74.15],
    [41.15, -74.15],
    [41.15, -74.45],
  ] as L.LatLngExpression[];

  const sullivanCounty = [
    [41.8, -74.9],
    [41.8, -74.5],
    [41.55, -74.5],
    [41.55, -74.9],
  ] as L.LatLngExpression[];

  const ulsterCounty = [
    [42.1, -74.6],
    [42.1, -74.0],
    [41.7, -74.0],
    [41.7, -74.6],
  ] as L.LatLngExpression[];

  const [activeCounty, setActiveCounty] = useState<string | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const isMobile = useIsMobile();

  // Wait until component is mounted before rendering the map
  useEffect(() => {
    setMapReady(true);
  }, []);

  const counties = [
    {
      name: "Orange County",
      towns: "Middletown, Newburgh, Monroe, Warwick, and surrounding areas",
      color: "#2D5A27",
      coordinates: orangeCounty,
    },
    {
      name: "Sullivan County",
      towns: "Monticello, Liberty, Callicoon, and surrounding areas",
      color: "#8B4513",
      coordinates: sullivanCounty,
    },
    {
      name: "Ulster County",
      towns: "Kingston, New Paltz, Saugerties, and surrounding areas",
      color: "#E55B13",
      coordinates: ulsterCounty,
    },
  ];

  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="container-custom">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="w-full lg:w-1/2">
            <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-6">
              Our Service Area
            </h2>
            <p className="mb-6">
              We proudly serve residential and commercial clients throughout
              Orange, Sullivan, and Ulster counties in New York. Our expert team
              is always ready to help with all your tree service needs.
            </p>

            <div className="space-y-4 mb-8">
              {counties.map((county) => (
                <div
                  key={county.name}
                  className="flex items-start gap-4 p-4 bg-white rounded-lg shadow-sm"
                  onMouseEnter={() => setActiveCounty(county.name)}
                  onMouseLeave={() => setActiveCounty(null)}
                >
                  <div className="text-accent mt-1">
                    <i className="fas fa-map-marker-alt"></i>
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-primary">
                      {county.name}
                    </h3>
                    <p className="text-sm">{county.towns}</p>
                  </div>
                </div>
              ))}
            </div>

            <Button className="bg-accent hover:bg-secondary" asChild>
              <a href="#contact">Check If We Serve Your Area</a>
            </Button>
          </div>

          <div className="w-full lg:w-1/2">
            <div className="bg-white p-4 rounded-lg shadow-md">
              <div className="h-[400px] rounded-md overflow-hidden">
                {mapReady && (
                  <MapContainer
                    center={[41.6, -74.5] as L.LatLngExpression}
                    zoom={9}
                    style={{ height: "100%", width: "100%" }}
                    scrollWheelZoom={false}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    {counties.map((county) => (
                      <Polygon
                        key={county.name}
                        positions={county.coordinates}
                        pathOptions={{
                          fillColor: county.color,
                          fillOpacity: activeCounty === county.name ? 0.8 : 0.5,
                          weight: 2,
                          color: county.color,
                        }}
                      >
                        <Tooltip>{county.name}</Tooltip>
                      </Polygon>
                    ))}
                  </MapContainer>
                )}
              </div>

              <div className="mt-4 grid grid-cols-3 gap-2 text-center text-sm">
                {counties.map((county) => (
                  <div
                    key={county.name}
                    className={`p-2 rounded`}
                    style={{ backgroundColor: `${county.color}20` }}
                  >
                    <span
                      className="font-semibold"
                      style={{ color: county.color }}
                    >
                      {county.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServiceAreaMap;
