import { Button } from "@/components/ui/button";

const HeroSection = () => {
  return (
    <section id="home" className="relative bg-primary text-white">
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1516383274235-5f42d6c6426d?auto=format&fit=crop&w=1920&h=800&q=80"
          alt="Professional tree service work"
          className="object-cover w-full h-full opacity-30"
        />
      </div>
      <div className="container-custom py-24 md:py-32 relative z-10">
        <div className="max-w-2xl">
          <h1 className="font-serif font-bold text-4xl md:text-5xl mb-6 leading-tight">
            Professional Tree Services by Certified Experts
          </h1>
          <p className="text-xl mb-8 leading-relaxed">
            Licensed, certified, and fully insured tree care professionals
            serving Orange, Sullivan, and Ulster counties. Our expert climbing
            techniques ensure safe and efficient solutions for all your tree
            needs.
          </p>
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
            <Button
              size="lg"
              className="bg-accent hover:bg-secondary transition-custom"
              asChild
            >
              <a href="#contact">Get a Free Quote</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-white text-primary hover:bg-gray-100 transition-custom"
              asChild
            >
              <a href="#services">View Our Services</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
