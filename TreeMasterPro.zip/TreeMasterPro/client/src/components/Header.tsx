import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, Menu, X } from "lucide-react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header
      className={`sticky top-0 z-50 bg-white ${
        isScrolled ? "shadow-md" : ""
      } transition-custom`}
    >
      <div className="container-custom py-4 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <div className="h-14 w-14 bg-primary rounded-full flex items-center justify-center text-white">
            <i className="fas fa-tree text-2xl"></i>
          </div>
          <div>
            <h1 className="text-primary font-serif text-xl md:text-2xl font-bold">
              Expert Tree Service
            </h1>
            <p className="text-secondary text-sm">
              Orange, Sullivan & Ulster Counties
            </p>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <a
            href="#home"
            className="font-sans font-semibold text-primary hover:text-accent transition-custom"
          >
            Home
          </a>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="font-sans font-semibold text-primary hover:text-accent transition-custom flex items-center gap-1">
                Services <ChevronDown size={16} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem>
                <a href="#tree-climbing" className="block w-full">
                  Expert Tree Climbing
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <a href="#tree-removal" className="block w-full">
                  Tree Removal
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <a href="#pruning" className="block w-full">
                  Pruning & Trimming
                </a>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <a href="#emergency" className="block w-full">
                  Emergency Services
                </a>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <a
            href="#about"
            className="font-sans font-semibold text-primary hover:text-accent transition-custom"
          >
            About
          </a>
          <a
            href="#gallery"
            className="font-sans font-semibold text-primary hover:text-accent transition-custom"
          >
            Gallery
          </a>
          <a href="#contact">
            <Button className="bg-accent hover:bg-secondary">Contact Us</Button>
          </a>
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-primary"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      <div
        className={`md:hidden bg-white shadow-lg absolute w-full transition-all duration-300 overflow-hidden ${
          isMenuOpen ? "max-h-64" : "max-h-0"
        }`}
      >
        <div className="container-custom py-4">
          <div className="flex flex-col space-y-4">
            <a
              href="#home"
              className="font-sans font-semibold text-primary hover:text-accent transition-custom py-2"
              onClick={closeMenu}
            >
              Home
            </a>
            <a
              href="#services"
              className="font-sans font-semibold text-primary hover:text-accent transition-custom py-2"
              onClick={closeMenu}
            >
              Services
            </a>
            <a
              href="#about"
              className="font-sans font-semibold text-primary hover:text-accent transition-custom py-2"
              onClick={closeMenu}
            >
              About
            </a>
            <a
              href="#gallery"
              className="font-sans font-semibold text-primary hover:text-accent transition-custom py-2"
              onClick={closeMenu}
            >
              Gallery
            </a>
            <a
              href="#contact"
              className="font-sans text-center px-6 py-3 bg-accent text-white rounded-md hover:bg-secondary transition-custom"
              onClick={closeMenu}
            >
              Contact Us
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
