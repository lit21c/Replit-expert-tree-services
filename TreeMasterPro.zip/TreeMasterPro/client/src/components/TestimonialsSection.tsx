import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface Testimonial {
  content: string;
  name: string;
  location: string;
}

const TestimonialsSection = () => {
  const testimonials: Testimonial[] = [
    {
      content:
        "Their climbing expertise was impressive. They removed a massive oak that was hanging over my house without any damage to my property. The cleanup was immaculate too!",
      name: "John Davis",
      location: "Middletown, NY",
    },
    {
      content:
        "Following a storm, I needed emergency tree removal. They came out the same day and took care of everything. Professional, efficient, and reasonable prices.",
      name: "Sarah Miller",
      location: "Kingston, NY",
    },
    {
      content:
        "We've been using Expert Tree Service for our commercial property for years. They're always reliable, professional, and their attention to detail makes all the difference.",
      name: "Michael Johnson",
      location: "Monticello, NY",
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [visibleItems, setVisibleItems] = useState(1);

  const nextTestimonial = () => {
    if (currentIndex < testimonials.length - visibleItems) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const prevTestimonial = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setVisibleItems(3);
      } else if (window.innerWidth >= 768) {
        setVisibleItems(2);
      } else {
        setVisibleItems(1);
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <section className="py-16 md:py-24 bg-primary text-white">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="font-serif font-bold text-3xl md:text-4xl mb-4">
            What Our Clients Say
          </h2>
          <p className="max-w-3xl mx-auto">
            Hear from satisfied customers about their experience with our tree
            services.
          </p>
        </div>

        <div className="relative">
          <div className="overflow-hidden">
            <div
              className="flex transition-transform duration-300 ease-in-out"
              style={{
                transform: `translateX(-${currentIndex * (100 / visibleItems)}%)`,
              }}
            >
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="flex-shrink-0"
                  style={{ width: `${100 / visibleItems}%` }}
                >
                  <div className="p-4">
                    <div className="bg-white text-[#333333] p-6 rounded-lg shadow-lg h-full">
                      <div className="text-accent mb-4">
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                        <i className="fas fa-star"></i>
                      </div>
                      <p className="italic mb-6">"{testimonial.content}"</p>
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-primary rounded-full mr-4 flex items-center justify-center text-white">
                          <i className="fas fa-user"></i>
                        </div>
                        <div>
                          <h4 className="font-semibold">{testimonial.name}</h4>
                          <p className="text-sm">{testimonial.location}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            className={`absolute left-0 top-1/2 transform -translate-y-1/2 bg-white p-3 rounded-full shadow-lg text-primary hover:text-accent md:-ml-5 z-10 ${
              currentIndex === 0 ? "opacity-50 cursor-not-allowed" : ""
            }`}
            onClick={prevTestimonial}
            disabled={currentIndex === 0}
            aria-label="Previous testimonial"
          >
            <ChevronLeft />
          </button>

          <button
            className={`absolute right-0 top-1/2 transform -translate-y-1/2 bg-white p-3 rounded-full shadow-lg text-primary hover:text-accent md:-mr-5 z-10 ${
              currentIndex >= testimonials.length - visibleItems
                ? "opacity-50 cursor-not-allowed"
                : ""
            }`}
            onClick={nextTestimonial}
            disabled={currentIndex >= testimonials.length - visibleItems}
            aria-label="Next testimonial"
          >
            <ChevronRight />
          </button>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
