import { Button } from "@/components/ui/button";

interface GalleryItem {
  image: string;
  title: string;
  description: string;
}

const GallerySection = () => {
  const galleryItems: GalleryItem[] = [
    {
      image: "https://images.unsplash.com/photo-1622383563203-a97819cb83c2?auto=format&fit=crop&w=600&h=400&q=80",
      title: "Tree Removal",
      description: "Safe removal of a damaged oak tree in Middletown",
    },
    {
      image: "https://images.unsplash.com/photo-1595841696146-d5bed87d04bd?auto=format&fit=crop&w=600&h=400&q=80",
      title: "Crown Reduction",
      description: "Professional pruning of maple trees in Kingston",
    },
    {
      image: "https://images.unsplash.com/photo-1520626525407-35e01e94f46e?auto=format&fit=crop&w=600&h=400&q=80",
      title: "Storm Damage Cleanup",
      description: "Emergency service after severe weather in Monticello",
    },
    {
      image: "https://images.unsplash.com/photo-1501684691657-cf3012635478?auto=format&fit=crop&w=600&h=400&q=80",
      title: "Technical Climbing",
      description: "Expert tree climbing for precise limb removal in New Paltz",
    },
    {
      image: "https://images.unsplash.com/photo-1591389298842-b1c0309c4fec?auto=format&fit=crop&w=600&h=400&q=80",
      title: "Land Clearing",
      description: "Commercial property clearing in Warwick",
    },
    {
      image: "https://images.unsplash.com/photo-1546860255-5fe479682be0?auto=format&fit=crop&w=600&h=400&q=80",
      title: "Stump Grinding",
      description: "Complete stump removal in Liberty",
    },
  ];

  return (
    <section id="gallery" className="py-16 md:py-24">
      <div className="container-custom">
        <div className="text-center mb-16">
          <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-4">
            Our Work Gallery
          </h2>
          <p className="max-w-3xl mx-auto">
            Take a look at some of our recent tree service projects throughout
            Orange, Sullivan, and Ulster counties.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryItems.map((item, index) => (
            <div key={index} className="gallery-item">
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-64 object-cover"
              />
              <div className="p-4 bg-white">
                <h3 className="font-serif font-bold text-lg text-primary">
                  {item.title}
                </h3>
                <p className="text-sm">{item.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button
            size="lg"
            className="bg-accent hover:bg-secondary transition-custom"
            asChild
          >
            <a href="#contact">Get Started with Your Project</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default GallerySection;
