const CredentialsBar = () => {
  return (
    <section className="bg-gray-50 py-6">
      <div className="container-custom">
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
          <div className="flex items-center gap-3">
            <i className="fas fa-certificate text-2xl text-accent"></i>
            <span className="font-semibold">Licensed & Certified</span>
          </div>
          <div className="flex items-center gap-3">
            <i className="fas fa-shield-alt text-2xl text-accent"></i>
            <span className="font-semibold">Fully Insured</span>
          </div>
          <div className="flex items-center gap-3">
            <i className="fas fa-tree text-2xl text-accent"></i>
            <span className="font-semibold">Expert Tree Climbers</span>
          </div>
          <div className="flex items-center gap-3">
            <i className="fas fa-phone-alt text-2xl text-accent"></i>
            <span className="font-semibold">24/7 Emergency Service</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CredentialsBar;
