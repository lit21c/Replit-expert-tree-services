import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { services } from "@/data/services";

const Services = () => {
  return (
    <>
      {/* Services Hero Section */}
      <section className="relative py-20 bg-gray-100">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl">
            <h1 className="font-serif font-bold text-4xl md:text-5xl text-primary mb-4">
              Our Professional Tree Services
            </h1>
            <p className="text-lg md:text-xl mb-6">
              Expert tree care services delivered by certified arborists and skilled climbers
            </p>
            <p className="mb-0">
              From routine maintenance to emergency storm damage, our team has the expertise
              and equipment to handle all your tree care needs in Orange, Sullivan, and Ulster counties.
            </p>
          </div>
        </div>
      </section>

      {/* Services List Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <Card key={service.id} className="bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg">
                <div className="h-48 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardContent className="p-6">
                  <div className="bg-primary inline-block p-3 rounded-full text-white mb-4">
                    <i className={service.icon + " text-xl"}></i>
                  </div>
                  <h3 className="font-serif font-bold text-xl mb-3">{service.title}</h3>
                  <p className="mb-4">{service.description}</p>
                  <Link href="/contact">
                    <a className="text-accent font-semibold hover:text-primary transition-colors inline-flex items-center">
                      Request Service <i className="fas fa-arrow-right ml-2"></i>
                    </a>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-4">
              Why Choose Evergreen Tree Services?
            </h2>
            <p className="text-lg max-w-3xl mx-auto">
              We combine professional expertise with personalized service to deliver
              the highest quality tree care in the Hudson Valley.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="mx-auto bg-primary/10 w-16 h-16 flex items-center justify-center rounded-full mb-4">
                <i className="fas fa-clipboard-check text-primary text-2xl"></i>
              </div>
              <h3 className="font-bold text-xl mb-2">Licensed & Insured</h3>
              <p>Fully licensed professionals with comprehensive insurance coverage for your protection</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="mx-auto bg-primary/10 w-16 h-16 flex items-center justify-center rounded-full mb-4">
                <i className="fas fa-tree text-primary text-2xl"></i>
              </div>
              <h3 className="font-bold text-xl mb-2">Expert Climbers</h3>
              <p>Specialized climbing techniques for safe and efficient tree work in difficult locations</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="mx-auto bg-primary/10 w-16 h-16 flex items-center justify-center rounded-full mb-4">
                <i className="fas fa-leaf text-primary text-2xl"></i>
              </div>
              <h3 className="font-bold text-xl mb-2">Environmentally Conscious</h3>
              <p>Eco-friendly practices that prioritize the health of your trees and property</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-md text-center">
              <div className="mx-auto bg-primary/10 w-16 h-16 flex items-center justify-center rounded-full mb-4">
                <i className="fas fa-phone-volume text-primary text-2xl"></i>
              </div>
              <h3 className="font-bold text-xl mb-2">24/7 Emergency Service</h3>
              <p>Always available for urgent tree situations that require immediate attention</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-2/3 mb-8 md:mb-0">
              <h2 className="font-serif font-bold text-3xl md:text-4xl mb-4">
                Need Professional Tree Service?
              </h2>
              <p className="text-lg">
                Contact us today to schedule a free consultation and estimate.
              </p>
            </div>
            <div>
              <Link href="/contact">
                <a className="inline-block bg-accent hover:bg-accent/90 text-white font-bold py-3 px-8 rounded-md transition-colors text-lg">
                  Contact Us Now
                </a>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Services;
