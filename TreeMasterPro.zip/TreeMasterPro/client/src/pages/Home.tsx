import HeroSection from "@/components/HeroSection";
import CredentialsBar from "@/components/CredentialsBar";
import ServicesSection from "@/components/ServicesSection";
import ServiceAreaMap from "@/components/ServiceAreaMap";
import AboutSection from "@/components/AboutSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import GallerySection from "@/components/GallerySection";
import CTASection from "@/components/CTASection";
import ContactSection from "@/components/ContactSection";

const Home = () => {
  return (
    <main>
      <HeroSection />
      <CredentialsBar />
      <ServicesSection />
      <ServiceAreaMap />
      <AboutSection />
      <TestimonialsSection />
      <GallerySection />
      <CTASection />
      <ContactSection />
    </main>
  );
};

export default Home;
