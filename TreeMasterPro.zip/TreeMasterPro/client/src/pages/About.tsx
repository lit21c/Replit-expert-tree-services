import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const About = () => {
  return (
    <>
      {/* About Hero Section */}
      <section className="relative py-20 bg-gray-100">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl">
            <h1 className="font-serif font-bold text-4xl md:text-5xl text-primary mb-4">
              About Evergreen Tree Services
            </h1>
            <p className="text-lg md:text-xl">
              Hudson Valley's trusted tree care professionals since 2005
            </p>
          </div>
        </div>
      </section>

      {/* Main About Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-16">
            <div className="lg:w-1/2">
              <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-6">
                Our Story
              </h2>
              <p className="text-lg mb-6">
                With over 15 years of experience serving New York's Hudson Valley region, 
                Evergreen Tree Services has built a reputation for excellence in professional 
                tree care. Our team of certified arborists and expert climbers are committed 
                to providing safe, efficient, and environmentally sound tree services.
              </p>
              
              <h3 className="font-serif font-bold text-xl text-secondary mb-4">
                Our Commitment to You
              </h3>
              <p className="mb-6">
                We believe in doing the job right the first time. From our detailed initial 
                assessments to our meticulous cleanup processes, we take pride in delivering 
                exceptional service that protects your property and enhances your landscape.
              </p>
              
              <h3 className="font-serif font-bold text-xl text-secondary mb-4">
                Professional Credentials
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fas fa-certificate text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-bold">ISA Certified Arborists</h4>
                    <p className="text-sm">International Society of Arboriculture</p>
                  </div>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fas fa-id-card text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-bold">NY State Licensed</h4>
                    <p className="text-sm">Fully licensed tree care professionals</p>
                  </div>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fas fa-shield-alt text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-bold">Fully Insured</h4>
                    <p className="text-sm">Liability and workers' compensation</p>
                  </div>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fas fa-medal text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-bold">TCIA Member</h4>
                    <p className="text-sm">Tree Care Industry Association</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="lg:w-1/2">
              <div className="grid grid-cols-2 gap-4 h-full">
                <div className="grid gap-4">
                  <div className="rounded-lg overflow-hidden shadow-md h-64">
                    <img 
                      src="https://images.unsplash.com/photo-1626934457734-94d3048318c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80" 
                      alt="Tree climbing expert" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="rounded-lg overflow-hidden shadow-md h-48">
                    <img 
                      src="https://images.unsplash.com/photo-1566235749748-6f9c5be74e43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1035&q=80" 
                      alt="Professional tree equipment" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                <div className="grid gap-4">
                  <div className="rounded-lg overflow-hidden shadow-md h-48">
                    <img 
                      src="https://images.unsplash.com/photo-1617861100566-274d81686201?ixlib=rb-4.0.3&auto=format&fit=crop&w=1032&q=80" 
                      alt="Tree service team" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="rounded-lg overflow-hidden shadow-md h-64">
                    <img 
                      src="https://images.unsplash.com/photo-1611067178760-508f7c5721b0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80" 
                      alt="Tree pruning work" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-4">
              Meet Our Team
            </h2>
            <p className="text-lg max-w-3xl mx-auto">
              Our team of certified arborists and skilled climbers brings decades of 
              combined experience to every project.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-80 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?ixlib=rb-4.0.3&auto=format&fit=crop&w=689&q=80" 
                  alt="Michael Johnson, Lead Arborist" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="font-serif font-bold text-xl mb-1">Michael Johnson</h3>
                <p className="text-accent mb-3">Lead Arborist & Founder</p>
                <p className="mb-4">
                  ISA Certified Arborist with over 20 years of experience in the tree care industry.
                </p>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-80 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=687&q=80" 
                  alt="David Williams, Operations Manager" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="font-serif font-bold text-xl mb-1">David Williams</h3>
                <p className="text-accent mb-3">Operations Manager</p>
                <p className="mb-4">
                  Oversees all field operations, ensuring safety standards and quality service on every job.
                </p>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="h-80 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80" 
                  alt="Sarah Martinez, Client Relations Manager" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="font-serif font-bold text-xl mb-1">Sarah Martinez</h3>
                <p className="text-accent mb-3">Client Relations Manager</p>
                <p className="mb-4">
                  Dedicated to providing exceptional customer service and personalized solutions.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-2/3 mb-8 md:mb-0">
              <h2 className="font-serif font-bold text-3xl md:text-4xl mb-4">
                Work With Our Expert Team
              </h2>
              <p className="text-lg">
                Contact us today to schedule a consultation with our certified arborists.
              </p>
            </div>
            <div>
              <Link href="/contact">
                <Button className="bg-accent hover:bg-accent/90 text-white font-bold py-3 px-8 rounded-md text-lg">
                  Contact Us Today
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
