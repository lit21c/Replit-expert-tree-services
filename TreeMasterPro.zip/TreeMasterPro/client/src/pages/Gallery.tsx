import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import BeforeAfterSlider from "@/components/BeforeAfterSlider";
import { gallery } from "@/data/gallery";

const Gallery = () => {
  const [loadMore, setLoadMore] = useState(false);
  const initialImages = gallery.slice(0, 6);
  const additionalImages = gallery.slice(6);
  
  const handleLoadMore = () => {
    setLoadMore(true);
  };

  return (
    <>
      {/* Gallery Hero Section */}
      <section className="relative py-20 bg-gray-100">
        <div className="container mx-auto px-6">
          <div className="max-w-3xl">
            <h1 className="font-serif font-bold text-4xl md:text-5xl text-primary mb-4">
              Our Work Gallery
            </h1>
            <p className="text-lg md:text-xl">
              Browse our portfolio of recent tree care projects throughout Orange, Sullivan, and Ulster counties
            </p>
          </div>
        </div>
      </section>

      {/* Before & After Section */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-4">
              Before & After
            </h2>
            <p className="text-lg max-w-3xl mx-auto">
              See the transformation in these before and after examples of our tree care work.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <BeforeAfterSlider 
              beforeImage="https://images.unsplash.com/photo-1610219542098-df1753da95c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
              afterImage="https://images.unsplash.com/photo-1602403260430-73c6b5daa979?ixlib=rb-4.0.3&auto=format&fit=crop&w=1169&q=80"
              title="Tree Removal"
              location="Middletown, NY"
            />
            
            <BeforeAfterSlider 
              beforeImage="https://images.unsplash.com/photo-1597305877032-0668b3c6413a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80"
              afterImage="https://images.unsplash.com/photo-1604085572504-a392ddf0d86a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80"
              title="Tree Pruning"
              location="Kingston, NY"
            />
          </div>
        </div>
      </section>

      {/* Photo Gallery Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-serif font-bold text-3xl md:text-4xl text-primary mb-4">
              Photo Gallery
            </h2>
            <p className="text-lg max-w-3xl mx-auto">
              A selection of our recent tree care projects throughout the Hudson Valley.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {initialImages.map((item) => (
              <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="h-64 overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-bold">{item.title}</h3>
                  <p className="text-sm text-gray-600">{item.location}</p>
                </div>
              </div>
            ))}
            
            {loadMore && additionalImages.map((item) => (
              <div key={item.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="h-64 overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-bold">{item.title}</h3>
                  <p className="text-sm text-gray-600">{item.location}</p>
                </div>
              </div>
            ))}
          </div>
          
          {!loadMore && (
            <div className="text-center mt-10">
              <Button 
                className="bg-secondary hover:bg-secondary/90 text-white font-bold py-3 px-6 rounded-md"
                onClick={handleLoadMore}
              >
                Load More Photos
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="md:w-2/3 mb-8 md:mb-0">
              <h2 className="font-serif font-bold text-3xl md:text-4xl mb-4">
                Ready to Transform Your Trees?
              </h2>
              <p className="text-lg">
                Contact us today to schedule your free consultation and estimate.
              </p>
            </div>
            <div>
              <Link href="/contact">
                <Button className="bg-accent hover:bg-accent/90 text-white font-bold py-3 px-8 rounded-md text-lg">
                  Get a Free Quote
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Gallery;
