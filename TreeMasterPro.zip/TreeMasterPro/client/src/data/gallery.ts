export const gallery = [
  {
    id: 1,
    title: "Crown Reduction",
    location: "Kingston, NY",
    image: "https://images.unsplash.com/photo-1605497788044-5a32c7078486?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80"
  },
  {
    id: 2,
    title: "Stump Grinding",
    location: "Newburgh, NY",
    image: "https://images.unsplash.com/photo-1637433370695-53a103c6ad57?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
  },
  {
    id: 3,
    title: "Emergency Removal",
    location: "Monticello, NY",
    image: "https://images.unsplash.com/photo-1640913544919-d46aec3e6b54?ixlib=rb-4.0.3&auto=format&fit=crop&w=1232&q=80"
  },
  {
    id: 4,
    title: "Cabling Installation",
    location: "Warwick, NY",
    image: "https://images.unsplash.com/photo-1610587244277-78e2cced9e83?ixlib=rb-4.0.3&auto=format&fit=crop&w=1094&q=80"
  },
  {
    id: 5,
    title: "Tree Health Treatment",
    location: "New Paltz, NY",
    image: "https://images.unsplash.com/photo-1611074584678-d80fe60832a6?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
  },
  {
    id: 6,
    title: "Tree Pruning",
    location: "Woodstock, NY",
    image: "https://images.unsplash.com/photo-1600125693227-ea73ff3cf321?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
  },
  {
    id: 7,
    title: "Land Clearing",
    location: "Port Jervis, NY",
    image: "https://images.unsplash.com/photo-1591643485702-54667a7802c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
  },
  {
    id: 8,
    title: "Tree Planting",
    location: "Liberty, NY",
    image: "https://images.unsplash.com/photo-1598335624134-059775ba10e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
  },
  {
    id: 9,
    title: "Hedge Maintenance",
    location: "Goshen, NY",
    image: "https://images.unsplash.com/photo-1597460056379-6e9a688bafc3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80"
  },
  {
    id: 10,
    title: "View Enhancement",
    location: "Saugerties, NY",
    image: "https://images.unsplash.com/photo-1516253593875-bd7ba052fbc5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
  }
];
