export const services = [
  {
    id: 1,
    title: "Tree Pruning and Trimming",
    description: "Expert pruning to improve tree health, appearance, and safety while encouraging proper growth patterns.",
    icon: "fas fa-cut",
    image: "https://images.unsplash.com/photo-1473448912268-2022ce9509d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1025&q=80"
  },
  {
    id: 2,
    title: "Tree Removal",
    description: "Safe removal of hazardous or unwanted trees using specialized climbing techniques and equipment.",
    icon: "fas fa-truck-monster",
    image: "https://images.unsplash.com/photo-1597733336794-12d05021d510?ixlib=rb-4.0.3&auto=format&fit=crop&w=1074&q=80"
  },
  {
    id: 3,
    title: "Emergency Storm Damage",
    description: "24/7 emergency service for storm-damaged trees that pose immediate safety risks to property.",
    icon: "fas fa-bolt",
    image: "https://images.unsplash.com/photo-1501084291732-13b1ba8f0ebc?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
  },
  {
    id: 4,
    title: "Stump Grinding",
    description: "Complete stump removal to eliminate tripping hazards and prevent regrowth of unwanted trees.",
    icon: "fas fa-cog",
    image: "https://images.unsplash.com/photo-1529236183275-4fdcf2bc987e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1167&q=80"
  },
  {
    id: 5,
    title: "Tree Health Assessment",
    description: "Professional evaluation of tree health to identify diseases, pests, and structural issues early.",
    icon: "fas fa-heartbeat",
    image: "https://images.unsplash.com/photo-1429052527558-604cb5aba1c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1148&q=80"
  },
  {
    id: 6,
    title: "Cabling and Bracing",
    description: "Structural support systems for valuable trees with weak branches or multiple trunks.",
    icon: "fas fa-link",
    image: "https://images.unsplash.com/photo-1568650113079-49a8eac5ff9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1170&q=80"
  }
];
