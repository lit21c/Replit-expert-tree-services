export const testimonials = [
  {
    id: 1,
    name: "James Reynolds",
    initials: "JR",
    location: "Middletown, NY",
    text: "Evergreen Tree Services did an amazing job removing a large, dangerous tree from our backyard. Their climbing experts were extremely skilled and took every precaution to protect our property. They left everything cleaner than when they arrived!",
    rating: 5,
    bgColor: "bg-primary"
  },
  {
    id: 2,
    name: "Sarah Miller",
    initials: "SM",
    location: "Kingston, NY",
    text: "We've used Evergreen for pruning our old oak trees for years. Their attention to detail and knowledge of proper tree care is impressive. They're always professional, on time, and fairly priced. I highly recommend them to anyone in Ulster County.",
    rating: 5,
    bgColor: "bg-secondary"
  },
  {
    id: 3,
    name: "David Thompson",
    initials: "DT",
    location: "Liberty, NY",
    text: "After a storm damaged several trees on our property, Evergreen Tree Services responded quickly and provided emergency service. Their team was efficient, knowledgeable, and took the time to explain what needed to be done. The cleanup was thorough. Great company!",
    rating: 4.5,
    bgColor: "bg-accent"
  },
  {
    id: 4,
    name: "Rebecca Williams",
    initials: "RW",
    location: "Newburgh, NY",
    text: "I cannot say enough good things about Evergreen Tree Services. They transformed our overgrown backyard by removing dead trees and expertly pruning our mature oaks. The team was courteous, professional, and their prices were very competitive.",
    rating: 5,
    bgColor: "bg-primary"
  },
  {
    id: 5,
    name: "Michael Johnson",
    initials: "MJ",
    location: "Monticello, NY",
    text: "The team at Evergreen did a fantastic job with our emergency tree removal after a storm. They arrived promptly, assessed the situation quickly, and had the dangerous branch safely removed within hours. Their expertise is unmatched!",
    rating: 5,
    bgColor: "bg-secondary"
  }
];
