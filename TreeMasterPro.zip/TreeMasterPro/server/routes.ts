import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { contactFormSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // Contact form submission
  app.post("/api/contact", async (req: Request, res: Response) => {
    try {
      // Validate form data
      const validatedData = contactFormSchema.parse(req.body);
      
      // Save contact form data
      const success = await storage.saveContactForm(validatedData);
      
      if (success) {
        // In a real application, you might want to send an email notification here
        return res.status(200).json({
          message: "Thank you for contacting us! We'll get back to you shortly."
        });
      } else {
        return res.status(500).json({
          message: "Failed to save your message. Please try again later."
        });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Invalid form data",
          errors: error.errors
        });
      }
      
      return res.status(500).json({
        message: "An error occurred while processing your request."
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
